<?php
include 'config.php';

$newsId = isset($_GET['id']) ? intval($_GET['id']) : 0;

$query = $pdo->prepare('SELECT * FROM news WHERE id = :id');
$query->execute(['id' => $newsId]);
$item = $query->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    echo '<p>Berita tidak ditemukan.</p>';
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($item['title']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .news-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand p-3 fs-4" href="index.php">Portal Berita</a>
        <div class="collapse navbar-collapse">
           
        </div>
    </nav>

    <div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-10">
            <div class="card mx-auto">
                <?php if (!empty($item['image'])): ?>
                    <img src="<?php echo htmlspecialchars($item['image']); ?>" class="card-img-top news-image" alt="Gambar Berita">
                <?php else: ?>
                    <img src="assets/placeholder.jpeg" class="card-img-top news-image" alt="Gambar Berita">
                <?php endif; ?>
                <div class="card-body">
                    <h1 class="card-title"><?php echo htmlspecialchars($item['title']); ?></h1>
                    <p class="card-text"><?php echo nl2br(htmlspecialchars($item['content'])); ?></p>
                </div>
                <a href="index.php" class="btn btn-secondary">Kembali</a>
            </div>
        </div>
    </div>
</div>

    <footer class="bg-dark text-white py-3">
        <div class="container text-center">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> Berita. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>